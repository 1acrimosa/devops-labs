# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = "secret_key"
