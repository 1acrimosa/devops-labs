SWAGGER = True

SWAGGER_SETTINGS = {
    "USE_SESSION_AUTH": False,
    "DEFAULT_AUTO_SCHEMA_CLASS": "common.swagger.SwaggerAutoSchema",
    # "SECURITY_DEFINITIONS": {
    #     "Token": {
    #         "type": "apiKey",
    #         "name": "Authorization",
    #         "in": "header",
    #     },
    # },
}
