#!/bin/bash

python manage.py collectstatic --noinput
# python manage.py compilemessages
python manage.py migrate

case "$ENV" in
"DEV")
    gunicorn common.wsgi --worker-class gevent --bind 0.0.0.0:8000 --reload --log-level debug
    ;;
"PRODUCTION")
    gunicorn common.wsgi --worker-class gevent --bind 0.0.0.0:8000 --workers $GUNICORN_WORKERS --timeout $GUNICORN_TIMEOUT --log-level info
    ;;
*)
    echo "NO ENV SPECIFIED!"
    exit 1
    ;;
esac
