#!/bin/bash
set -o errexit
set -o pipefail
set -o nounset

celery -A common.celery:app worker -l $CELERY_LOG_LEVEL -Q $CELERY_QUEUE_NAME -P gevent -c $CELERY_CONCURENCY
