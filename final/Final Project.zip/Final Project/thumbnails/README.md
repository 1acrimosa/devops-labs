# Django

## Requirements

- [Python 3.13](https://www.python.org/downloads/)
- [Docker](https://docs.docker.com/get-docker/)
- [Docker Compose](https://docs.docker.com/compose/install/)
- [Poetry](https://python-poetry.org/docs/#installation)


## Getting started

Run the development server (the server is accessible at [http://localhost:8000](http://localhost:8000)):
```bash
docker compose up --build
```

## Development

Install the project dependencies:
```bash
pip install poetry
make install
```

Run format, test, and scan checks:
```bash
make all
```

Create a superuser:
```bash
docker compose run -it app python manage.py createsuperuser
```

## Useful endpoints

- [http://localhost:8000/healthcheck/](http://localhost:8000/healthcheck/) - Health check endpoint.
- [http://localhost:8000/admin/](http://localhost:8000/admin/) - Django admin panel. 
- [http://localhost:8000/api/v1/swagger/](http://localhost:8000/api/v1/swagger/) - Swagger documentation.
- [http://localhost:8000/api/v1/metrics/](http://localhost:8000/api/v1/metrics/) - Metrics endpoint.
- [http://localhost:8000/api/v1/thumbnails/<max_height>x<max_width>/<url>/](http://localhost:8000/api/v1/thumbnails/512x512/https://picsum.photos/1000/) - Thumbnail endpoint.


## Useful commands

Run all the checks:
```bash
make all
```

Format the code:
```bash
make format
```

Check the code formatting:
```bash
make format_check
```

Lint the code:
```bash
make static
```

Test the code:
```bash
make test
```

Test the code with coverage report:
```bash
make test_coverage
```

Scan the code:
```bash
make scan
```

Run pre-commit hooks:
```bash
make pre_commit
```


## Project structure

- `docker-compose.yml` - a docker compose file only for the local deployment. For the production deployment it is not used.
- `Makefile` - a collection of useful scripts for development.
- `README.md` - a documentation about the project.
- `pyproject.toml` - a meta file for poetry.
- `poetry.lock` - a lock file for poetry.
- `src/*` - source code.
- `docker/*` - docker staffs.
- `.gitignore` - a gitignore file specifies intentionally untracked files that git should ignore.
- `.flake8` - a config file for flake8.
- `.mypy.ini` - a config file for mypy.
- `.isort.cfg` - a config file for isort.
- `.pytest.ini` - a config file for pytest.
- `.safety-policy.yml` - a config file for safety.
